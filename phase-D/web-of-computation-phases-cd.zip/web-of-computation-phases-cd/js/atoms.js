/* ============================================================
   THE WEB OF COMPUTATION — atoms.js  (PHASE C: playable atoms)
   ------------------------------------------------------------
   Five toys, one overlay, zero dependencies.
   Self-injecting: this file creates its own DOM + CSS, so the
   ONLY integration step is  <script src="js/atoms.js"></script>
   placed after app.js in index.html.

   Public API (used by app.js field panels, optional):
     window.openAtomFromField(fieldId)  — opens the atom mapped
                                          to that field, if any
     window.ATOM_FOR                    — field-id → atom-id map

   The five atoms:
     1. turing      — binary-increment Turing machine, steppable
     2. enigma      — 3-rotor Enigma with real Wehrmacht wirings
     3. perceptron  — train a perceptron on XOR, watch it fail,
                      add a hidden layer, watch it win (Minsky
                      1969 → backprop 1986, as a toy)
     4. marble      — gradient descent on a two-valley loss
     5. attention   — a real 4-token softmax(QKᵀ/√d)V head
   ============================================================ */
(function () {
"use strict";

/* ---------- field → atom routing (matches data.js field ids) */
const ATOM_FOR = {
  "computability":   "turing",
  "classic-crypto":  "enigma",
  "prehistory":      "perceptron",
  "classic-ml":      "perceptron",
  "deep":            "marble",
  "optimization":    "marble",
  "llm":             "attention",
  "transformers":    "attention"
};
const ATOM_META = {
  turing:     { tab: "Turing machine",   sub: "1936 · the atom of computation" },
  enigma:     { tab: "Enigma",           sub: "1940 · what Bletchley was up against" },
  perceptron: { tab: "Perceptron vs XOR",sub: "1958 → 1969 → 1986 · fall and rise of the neuron" },
  marble:     { tab: "Gradient descent", sub: "how every network actually learns" },
  attention:  { tab: "Attention head",   sub: "2017 · the mechanism reading this page" }
};

/* ============================================================
   CSS — injected, fully scoped under #atoms / #atoms-launch
   ============================================================ */
const css = `
#atoms-launch{position:fixed;right:18px;bottom:88px;z-index:60;
  font-family:"IBM Plex Mono",monospace;font-size:12.5px;letter-spacing:.04em;
  color:#0b0f1c;background:linear-gradient(135deg,#f5c86b,#e8a94d);
  border:none;border-radius:999px;padding:10px 16px;cursor:pointer;
  box-shadow:0 0 18px rgba(245,200,107,.45),0 4px 14px rgba(0,0,0,.5);
  transition:transform .18s ease, box-shadow .18s ease}
#atoms-launch:hover{transform:translateY(-2px);box-shadow:0 0 26px rgba(245,200,107,.65),0 6px 18px rgba(0,0,0,.5)}
#atoms{position:fixed;inset:0;z-index:70;display:flex;align-items:center;justify-content:center;
  background:rgba(4,7,16,.72);backdrop-filter:blur(9px);-webkit-backdrop-filter:blur(9px)}
#atoms[hidden]{display:none}
#atoms .shell{width:min(880px,94vw);max-height:92vh;overflow:auto;
  background:linear-gradient(160deg,rgba(16,22,42,.96),rgba(9,13,27,.96));
  border:1px solid rgba(245,200,107,.22);border-radius:18px;
  box-shadow:0 0 60px rgba(120,150,255,.12),0 24px 60px rgba(0,0,0,.6);
  padding:22px 26px 26px;color:#dfe6f5}
#atoms h2{font-family:Fraunces,Georgia,serif;font-weight:600;font-size:24px;margin:0 0 2px;color:#f3ecdc}
#atoms .sub{font-family:"IBM Plex Mono",monospace;font-size:11.5px;color:#8fa0c9;margin:0 0 14px}
#atoms .tabs{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px}
#atoms .atom-tab{font-family:"IBM Plex Mono",monospace;font-size:11.5px;letter-spacing:.03em;
  color:#aab6d8;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);
  border-radius:999px;padding:6px 13px;cursor:pointer;transition:all .15s ease}
#atoms .atom-tab:hover{border-color:rgba(245,200,107,.5);color:#f5c86b}
#atoms .atom-tab.on{background:rgba(245,200,107,.16);border-color:#f5c86b;color:#f5c86b}
#atoms-close{position:absolute;margin:0;float:right;font-size:18px;line-height:1;
  color:#8fa0c9;background:none;border:none;cursor:pointer;padding:4px 8px}
#atoms-close:hover{color:#f5c86b}
#atoms .pane[hidden]{display:none}
#atoms .story{font-family:Spectral,Georgia,serif;font-size:14.5px;line-height:1.55;color:#c4cde4;margin:0 0 14px}
#atoms .story b{color:#f3ecdc}
#atoms .row{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:10px 0}
#atoms button.act{font-family:"IBM Plex Mono",monospace;font-size:12px;color:#eaf0ff;
  background:rgba(120,150,255,.14);border:1px solid rgba(120,150,255,.4);
  border-radius:8px;padding:7px 13px;cursor:pointer;transition:all .15s}
#atoms button.act:hover{background:rgba(120,150,255,.26)}
#atoms button.act.gold{background:rgba(245,200,107,.14);border-color:rgba(245,200,107,.55);color:#f5c86b}
#atoms button.act.gold:hover{background:rgba(245,200,107,.26)}
#atoms button.act:disabled{opacity:.35;cursor:default}
#atoms .mono{font-family:"IBM Plex Mono",monospace}
#atoms .readout{font-family:"IBM Plex Mono",monospace;font-size:12px;color:#9fe8c0;
  background:rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.08);border-radius:8px;padding:8px 12px;min-height:18px}
#atoms input[type=range]{accent-color:#f5c86b}
#atoms label{font-family:"IBM Plex Mono",monospace;font-size:11.5px;color:#8fa0c9}
#atoms canvas{border-radius:12px;background:#070b17;border:1px solid rgba(255,255,255,.08);
  display:block;max-width:100%}
/* Turing tape */
#tm-tape{display:flex;gap:5px;flex-wrap:wrap;margin:12px 0}
#tm-tape .cell{width:38px;height:46px;display:flex;align-items:center;justify-content:center;
  font-family:"IBM Plex Mono",monospace;font-size:19px;color:#dfe6f5;
  background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.13);border-radius:8px;transition:all .15s}
#tm-tape .cell.head{border-color:#f5c86b;color:#f5c86b;background:rgba(245,200,107,.12);
  box-shadow:0 0 14px rgba(245,200,107,.35);transform:translateY(-3px)}
/* Enigma */
#en-rotors{display:flex;gap:12px;margin:10px 0}
.en-rotor{width:64px;text-align:center;background:rgba(255,255,255,.04);
  border:1px solid rgba(255,255,255,.13);border-radius:10px;padding:8px 0}
.en-rotor .win{font-family:"IBM Plex Mono",monospace;font-size:22px;color:#f5c86b}
.en-rotor .nm{font-size:10px;color:#8fa0c9;font-family:"IBM Plex Mono",monospace;margin-top:3px}
#en-keys,#en-lamps{display:grid;grid-template-columns:repeat(9,1fr);gap:5px;margin:8px 0;max-width:430px}
#en-keys button{font-family:"IBM Plex Mono",monospace;font-size:13px;color:#dfe6f5;
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.14);border-radius:7px;
  padding:7px 0;cursor:pointer}
#en-keys button:hover{border-color:#f5c86b;color:#f5c86b}
#en-lamps .lamp{font-family:"IBM Plex Mono",monospace;font-size:13px;text-align:center;
  color:#3d4763;padding:7px 0;border-radius:7px;border:1px solid rgba(255,255,255,.06);transition:all .12s}
#en-lamps .lamp.lit{color:#0b0f1c;background:#f5c86b;box-shadow:0 0 16px rgba(245,200,107,.7);border-color:#f5c86b}
/* attention heatmap */
#at-grid{display:grid;grid-template-columns:70px repeat(4,64px);gap:4px;margin:12px 0;
  font-family:"IBM Plex Mono",monospace;font-size:12px}
#at-grid .hd{color:#8fa0c9;display:flex;align-items:center;justify-content:center;padding:4px}
#at-grid .cellw{height:44px;border-radius:7px;display:flex;align-items:center;justify-content:center;
  color:#0b0f1c;cursor:default;border:1px solid rgba(255,255,255,.05)}
@media (prefers-reduced-motion: reduce){
  #atoms *,#atoms-launch{transition:none !important;animation:none !important}}
`;

/* ============================================================
   DOM — the overlay shell
   ============================================================ */
const style = document.createElement("style");
style.textContent = css;
document.head.appendChild(style);

const wrap = document.createElement("div");
wrap.id = "atoms";
wrap.hidden = true;
wrap.innerHTML = `
<div class="shell" role="dialog" aria-label="Playable atoms">
  <button id="atoms-close" aria-label="Close">✕</button>
  <h2>Playable atoms</h2>
  <p class="sub">history you can poke — each toy is the real mechanism, miniaturised</p>
  <div class="tabs">${Object.keys(ATOM_META).map(k =>
    `<button class="atom-tab" data-atom="${k}">${ATOM_META[k].tab}</button>`).join("")}
  </div>

  <!-- 1 · TURING -->
  <section class="pane" id="pane-turing" hidden>
    <p class="story"><b>1936.</b> Turing's answer to Hilbert: strip computation to a tape, a head,
      and a table of rules. This machine does one job — <b>add 1 to a binary number</b>.
      Step it and watch the carry ripple. Everything on this map, including the model that
      built it, is this machine wearing better clothes.</p>
    <div id="tm-tape"></div>
    <div class="row">
      <button class="act gold" id="tm-step">step</button>
      <button class="act" id="tm-run">run</button>
      <button class="act" id="tm-reset">reset</button>
      <span class="readout" id="tm-state"></span>
    </div>
  </section>

  <!-- 2 · ENIGMA -->
  <section class="pane" id="pane-enigma" hidden>
    <p class="story"><b>1940.</b> Three rotors (real Wehrmacht wirings I·II·III), a reflector,
      and a cruel property: the rotors step <b>before</b> every letter, so the cipher alphabet
      changes with each keypress — yet the machine is reciprocal (encrypting the ciphertext
      returns your plaintext; set the rotors back and try it). The reflector also guarantees
      a letter never maps to itself — the flaw Bletchley drove a crib through.</p>
    <div id="en-rotors">
      <div class="en-rotor"><div class="win" id="en-r0">A</div><div class="nm">rotor III</div></div>
      <div class="en-rotor"><div class="win" id="en-r1">A</div><div class="nm">rotor II</div></div>
      <div class="en-rotor"><div class="win" id="en-r2">A</div><div class="nm">rotor I</div></div>
      <button class="act" id="en-reset" style="align-self:center">reset rotors</button>
    </div>
    <div id="en-keys"></div>
    <div id="en-lamps"></div>
    <div class="readout mono" id="en-log">type a message on the keys above…</div>
  </section>

  <!-- 3 · PERCEPTRON -->
  <section class="pane" id="pane-perceptron" hidden>
    <p class="story"><b>1958.</b> Rosenblatt's perceptron — one neuron, one straight line.
      Train it on XOR (gold = 1, blue = 0) and watch the line thrash: <b>no line can
      separate these four points</b>. That is Minsky &amp; Papert's 1969 objection, and it
      helped freeze the field. Then press the gold button: one hidden layer, backprop,
      and the boundary bends. The 🧟 revival, as a toy.</p>
    <canvas id="pc-cv" width="300" height="300"></canvas>
    <div class="row">
      <button class="act" id="pc-train">train perceptron</button>
      <button class="act gold" id="pc-hidden">add a hidden layer (1986)</button>
      <button class="act" id="pc-reset">reset</button>
    </div>
    <div class="readout" id="pc-out"></div>
  </section>

  <!-- 4 · MARBLE -->
  <section class="pane" id="pane-marble" hidden>
    <p class="story">Every network on this map learns the same way: drop a marble on the loss
      surface and let it roll downhill, step size = <b>learning rate</b>. Small steps crawl and
      get trapped in the shallow valley; crank the rate too high and the marble <b>diverges</b> —
      the single most-reproduced bug in deep learning, live.</p>
    <canvas id="gd-cv" width="560" height="240"></canvas>
    <div class="row">
      <label>learning rate <input type="range" id="gd-lr" min="-3" max="0.4" step="0.02" value="-1.6"></label>
      <span class="readout mono" id="gd-lrv"></span>
      <button class="act gold" id="gd-drop">drop marble</button>
      <button class="act" id="gd-stop">stop</button>
    </div>
    <div class="readout" id="gd-out"></div>
  </section>

  <!-- 5 · ATTENTION -->
  <section class="pane" id="pane-attention" hidden>
    <p class="story"><b>2017.</b> A real single attention head over four tokens — genuinely
      computing softmax(QKᵀ/√d)·V, no fakery. Each row shows where that token <b>looks</b>:
      brighter gold = more weight. This head has been given grammar: <b>“sat” attends
      to “cat”</b> (verbs seek their subject), <b>“cat” attends to “the”</b> (nouns find
      their determiner), <b>“down” attends to “sat”</b> (particles find their verb).
      Drag the temperature: low = the head commits hard; high = it hedges toward uniform.
      Stack a few hundred of these and you get the model reading this sentence.</p>
    <div id="at-grid"></div>
    <div class="row">
      <label>temperature <input type="range" id="at-temp" min="0.2" max="4" step="0.05" value="1"></label>
      <span class="readout mono" id="at-tv"></span>
    </div>
    <div class="readout" id="at-out"></div>
  </section>
</div>`;
document.body.appendChild(wrap);

const launch = document.createElement("button");
launch.id = "atoms-launch";
launch.textContent = "⚛ playable atoms";
document.body.appendChild(launch);

/* ---------- overlay plumbing ---------- */
const $ = id => document.getElementById(id);
let raf = {};                      // per-atom animation handles
function stopAll(){ Object.values(raf).forEach(cancelAnimationFrame); raf = {}; }

const INIT = {};                   // filled per-atom below
function showAtom(id){
  document.querySelectorAll("#atoms .atom-tab").forEach(b =>
    b.classList.toggle("on", b.dataset.atom === id));
  document.querySelectorAll("#atoms .pane").forEach(p =>
    p.hidden = (p.id !== "pane-" + id));
  stopAll(); INIT[id]();
}
function openAtom(id){ wrap.hidden = false; showAtom(id); }
function closeAtoms(){ wrap.hidden = true; stopAll(); }

launch.addEventListener("click", () => openAtom("turing"));
$("atoms-close").addEventListener("click", closeAtoms);
wrap.addEventListener("click", e => { if (e.target === wrap) closeAtoms(); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && !wrap.hidden) closeAtoms(); });
document.querySelectorAll("#atoms .atom-tab").forEach(b =>
  b.addEventListener("click", () => showAtom(b.dataset.atom)));

window.ATOM_FOR = ATOM_FOR;
window.openAtomFromField = fieldId => { const a = ATOM_FOR[fieldId]; if (a) openAtom(a); };

/* ============================================================
   1 · TURING MACHINE — binary increment
   ============================================================ */
const TM = {
  rules: { // state → symbol → [write, move, nextState]
    "R": { "0": ["0", 1, "R"], "1": ["1", 1, "R"], "_": ["_", -1, "C"] },
    "C": { "1": ["0", -1, "C"], "0": ["1", 0, "HALT"], "_": ["1", 0, "HALT"] }
  },
  desc: {
    "R": "state R — scan right to find the end of the number",
    "C": "state C — carry: 1→0 and keep moving left; the first 0 (or blank) becomes 1",
    "HALT": "HALT — done. 1011 (11) has become 1100 (12). Run it again from reset."
  }
};
function tmReset(){ TM.tape = "_1011______".split(""); TM.head = 1; TM.state = "R"; TM.n = 0; tmDraw(); }
function tmStep(){
  if (TM.state === "HALT") return;
  const sym = TM.tape[TM.head] || "_";
  const r = TM.rules[TM.state][sym];
  TM.tape[TM.head] = r[0]; TM.head += r[1]; TM.state = r[2]; TM.n++;
  tmDraw();
}
function tmDraw(){
  const t = $("tm-tape"); t.innerHTML = "";
  TM.tape.forEach((c, i) => {
    const d = document.createElement("div");
    d.className = "cell" + (i === TM.head ? " head" : "");
    d.textContent = c === "_" ? "·" : c;
    t.appendChild(d);
  });
  $("tm-state").textContent = `step ${TM.n} · ${TM.desc[TM.state]}`;
}
$("tm-step").addEventListener("click", tmStep);
$("tm-reset").addEventListener("click", tmReset);
$("tm-run").addEventListener("click", () => {
  const tick = () => { if (TM.state !== "HALT") { tmStep(); raf.tm = setTimeout(tick, 420); } };
  clearTimeout(raf.tm); tick();
});
INIT.turing = () => { clearTimeout(raf.tm); tmReset(); };

/* ============================================================
   2 · ENIGMA — rotors I, II, III + reflector B (historical wirings)
   ============================================================ */
const A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const EN = {
  // wirings written as: entering at position i (right side) exits at wiring[i]
  wheels: [
    { w: "BDFHJLCPRTXVZNYEIWGAKMUSQO", notch: "V" }, // rotor III (fast, rightmost)
    { w: "AJDKSIRUXBLHWTMCQGZNPYFVOE", notch: "E" }, // rotor II
    { w: "EKMFLGDQVZNTOWYHXUSPAIBRCJ", notch: "Q" }  // rotor I  (slow)
  ],
  refl: "YRUHQSLDPXNGOKMIEBFZCWVJAT",                 // UKW-B
  pos: [0, 0, 0], log: ""
};
const mod = (n, m) => ((n % m) + m) % m;
function enStep(){
  // simplified odometer stepping (notch → advance next), incl. the famous pre-step
  const w = EN.wheels;
  const atNotch = i => A[EN.pos[i]] === w[i].notch;
  const bump1 = atNotch(0), bump2 = atNotch(1);
  EN.pos[0] = mod(EN.pos[0] + 1, 26);
  if (bump1 || bump2) EN.pos[1] = mod(EN.pos[1] + 1, 26);   // double-step included
  if (bump2)          EN.pos[2] = mod(EN.pos[2] + 1, 26);
}
function thru(w, pos, cIdx, back){
  const shift = i => mod(i + pos, 26), unshift = i => mod(i - pos, 26);
  if (!back) return unshift(A.indexOf(w.w[shift(cIdx)]));
  return unshift(w.w.indexOf(A[shift(cIdx)]));
}
function enEncrypt(ch){
  enStep();
  let i = A.indexOf(ch);
  for (let r = 0; r < 3; r++) i = thru(EN.wheels[r], EN.pos[r], i, false); // → in
  i = A.indexOf(EN.refl[i]);                                              // reflect
  for (let r = 2; r >= 0; r--) i = thru(EN.wheels[r], EN.pos[r], i, true); // ← out
  return A[i];
}
function enDraw(lit){
  ["en-r0","en-r1","en-r2"].forEach((id, i) => $(id).textContent = A[EN.pos[i]]);
  document.querySelectorAll("#en-lamps .lamp").forEach(l =>
    l.classList.toggle("lit", l.textContent === lit));
}
function enBuild(){
  $("en-keys").innerHTML  = A.split("").map(c => `<button>${c}</button>`).join("");
  $("en-lamps").innerHTML = A.split("").map(c => `<div class="lamp">${c}</div>`).join("");
  document.querySelectorAll("#en-keys button").forEach(b =>
    b.addEventListener("click", () => {
      const out = enEncrypt(b.textContent);
      EN.log += b.textContent; 
      $("en-log").textContent = EN.log.slice(-24) + "  →  " +
        (($("en-log").dataset.out || "") + out).slice(-24);
      $("en-log").dataset.out = ($("en-log").dataset.out || "") + out;
      enDraw(out);
    }));
  $("en-reset").addEventListener("click", () => {
    EN.pos = [0,0,0]; EN.log = ""; $("en-log").dataset.out = "";
    $("en-log").textContent = "rotors back to AAA — now type your ciphertext to decrypt it";
    enDraw(null);
  });
}
INIT.enigma = () => {
  if (!$("en-keys").children.length) enBuild();
  enDraw(null);
};

/* ============================================================
   3 · PERCEPTRON vs XOR  (then MLP + backprop)
   ============================================================ */
const PC = {};
const XOR = [ {x:0,y:0,t:0}, {x:1,y:1,t:0}, {x:0,y:1,t:1}, {x:1,y:0,t:1} ];
function pcReset(){
  PC.mode = "perceptron";
  PC.w = [Math.random()-.5, Math.random()-.5]; PC.b = Math.random()-.5;
  // MLP: 2 → 3 → 1, tanh hidden, sigmoid out
  PC.W1 = [...Array(3)].map(()=>[rnd(),rnd()]); PC.b1=[rnd(),rnd(),rnd()];
  PC.W2 = [rnd(),rnd(),rnd()]; PC.b2 = rnd();
  PC.epoch = 0; PC.training = false;
  pcDraw(); $("pc-out").textContent = "untrained — press a button";
}
const rnd = () => (Math.random()-.5)*2;
const sig = z => 1/(1+Math.exp(-z));
function mlpFwd(x,y){
  const h = PC.W1.map((w,i)=>Math.tanh(w[0]*x+w[1]*y+PC.b1[i]));
  const o = sig(h.reduce((s,hi,i)=>s+PC.W2[i]*hi,PC.b2));
  return {h,o};
}
function pcTick(){
  if (!PC.training) return;
  if (PC.mode === "perceptron"){
    for (const p of XOR){
      const out = (PC.w[0]*p.x + PC.w[1]*p.y + PC.b) > 0 ? 1 : 0;
      const e = p.t - out, lr = .12;
      PC.w[0]+=lr*e*p.x; PC.w[1]+=lr*e*p.y; PC.b+=lr*e;
    }
    PC.epoch++;
    const errs = XOR.filter(p => ((PC.w[0]*p.x+PC.w[1]*p.y+PC.b)>0?1:0)!==p.t).length;
    $("pc-out").textContent = `perceptron · epoch ${PC.epoch} · ${errs}/4 wrong — the line will thrash forever (Minsky was right)`;
  } else {
    for (let k=0;k<40;k++) for (const p of XOR){
      const {h,o} = mlpFwd(p.x,p.y);
      const dO = (o-p.t)*o*(1-o), lr=.6;
      for (let i=0;i<3;i++){
        const dH = dO*PC.W2[i]*(1-h[i]*h[i]);
        PC.W2[i]-=lr*dO*h[i];
        PC.W1[i][0]-=lr*dH*p.x; PC.W1[i][1]-=lr*dH*p.y; PC.b1[i]-=lr*dH;
      }
      PC.b2-=lr*dO;
    }
    PC.epoch+=40;
    const loss = XOR.reduce((s,p)=>{const o=mlpFwd(p.x,p.y).o;return s+(o-p.t)**2;},0);
    $("pc-out").textContent = `hidden layer + backprop · epoch ${PC.epoch} · loss ${loss.toFixed(4)} — the boundary bends`;
    if (loss < .002) PC.training = false;
  }
  pcDraw();
  raf.pc = requestAnimationFrame(pcTick);
}
function pcDraw(){
  const cv = $("pc-cv"), c = cv.getContext("2d"), S = 300, m = 45;
  const X = v => m + v*(S-2*m), Y = v => S - (m + v*(S-2*m));
  c.clearRect(0,0,S,S);
  // decision regions
  const img = c.createImageData(S,S);
  for (let py=0;py<S;py+=2) for (let px=0;px<S;px+=2){
    const x=(px-m)/(S-2*m), y=(S-py-m)/(S-2*m);
    let v;
    if (PC.mode==="perceptron") v = (PC.w[0]*x+PC.w[1]*y+PC.b)>0 ? 1 : 0;
    else v = mlpFwd(x,y).o > .5 ? 1 : 0;
    const [r,g,b] = v ? [245,200,107] : [90,120,255];
    for (const [dx,dy] of [[0,0],[1,0],[0,1],[1,1]]){
      const q=4*((py+dy)*S+(px+dx));
      img.data[q]=r; img.data[q+1]=g; img.data[q+2]=b; img.data[q+3]=26;
    }
  }
  c.putImageData(img,0,0);
  // points
  for (const p of XOR){
    c.beginPath(); c.arc(X(p.x),Y(p.y),9,0,7);
    c.fillStyle = p.t ? "#f5c86b" : "#5a78ff";
    c.shadowColor = c.fillStyle; c.shadowBlur = 12; c.fill(); c.shadowBlur = 0;
    c.fillStyle="#0b0f1c"; c.font="bold 10px IBM Plex Mono, monospace";
    c.textAlign="center"; c.textBaseline="middle"; c.fillText(p.t, X(p.x), Y(p.y));
  }
}
$("pc-train").addEventListener("click", () => { PC.mode="perceptron"; PC.training=true; cancelAnimationFrame(raf.pc); pcTick(); });
$("pc-hidden").addEventListener("click", () => { PC.mode="mlp"; PC.training=true; cancelAnimationFrame(raf.pc); pcTick(); });
$("pc-reset").addEventListener("click", () => { cancelAnimationFrame(raf.pc); pcReset(); });
INIT.perceptron = () => { cancelAnimationFrame(raf.pc); pcReset(); };

/* ============================================================
   4 · GRADIENT-DESCENT MARBLE — two-valley loss
   ============================================================ */
const GD = { f: x => 0.05*x*x*x*x - 0.5*x*x + 0.15*x + 2.2,
             df: x => 0.2*x*x*x - x + 0.15 };
function gdDraw(){
  const cv=$("gd-cv"), c=cv.getContext("2d"), W=560, H=240;
  const X=x=>W/2+x*70, Y=v=>H-28-v*52;
  c.clearRect(0,0,W,H);
  c.beginPath();
  for (let px=0;px<=W;px++){ const x=(px-W/2)/70, v=GD.f(x);
    px?c.lineTo(px,Y(v)):c.moveTo(px,Y(v)); }
  c.strokeStyle="rgba(160,180,255,.8)"; c.lineWidth=2; c.stroke();
  // trail
  c.strokeStyle="rgba(245,200,107,.35)"; c.lineWidth=1.4; c.beginPath();
  (GD.trail||[]).forEach((x,i)=>{ i?c.lineTo(X(x),Y(GD.f(x))):c.moveTo(X(x),Y(GD.f(x))); });
  c.stroke();
  if (GD.x !== undefined && isFinite(GD.x)){
    c.beginPath(); c.arc(X(GD.x),Y(GD.f(GD.x)),8,0,7);
    c.fillStyle="#f5c86b"; c.shadowColor="#f5c86b"; c.shadowBlur=14; c.fill(); c.shadowBlur=0;
  }
  c.fillStyle="#8fa0c9"; c.font="11px IBM Plex Mono, monospace";
  c.fillText("shallow valley (local min)", 60, 60);
  c.fillText("deep valley (global min)", 380, 200);
}
function gdLr(){ return Math.pow(10, parseFloat($("gd-lr").value)); }
function gdLoop(){
  const lr = gdLr();
  GD.x -= lr * GD.df(GD.x);
  GD.trail.push(GD.x); if (GD.trail.length>400) GD.trail.shift();
  if (!isFinite(GD.x) || Math.abs(GD.x)>40){
    $("gd-out").textContent = `💥 diverged at lr=${lr.toFixed(3)} — the marble was flung off the surface. Lower the rate and drop again.`;
    GD.x = undefined; gdDraw(); return;
  }
  gdDraw();
  const g = Math.abs(GD.df(GD.x));
  $("gd-out").textContent = `x=${GD.x.toFixed(3)} · loss=${GD.f(GD.x).toFixed(3)} · |∇|=${g.toFixed(4)}` +
    (g<1e-3 ? "  → converged. Was it the deep valley or the shallow trap?" : "");
  if (g>=1e-3) raf.gd = requestAnimationFrame(gdLoop);
}
$("gd-lr").addEventListener("input", () => $("gd-lrv").textContent = "η = "+gdLr().toFixed(3));
$("gd-drop").addEventListener("click", () => {
  cancelAnimationFrame(raf.gd);
  GD.x = -3.1 + Math.random()*6.2; GD.trail = [GD.x];
  gdLoop();
});
$("gd-stop").addEventListener("click", () => cancelAnimationFrame(raf.gd));
INIT.marble = () => { cancelAnimationFrame(raf.gd); GD.x=undefined; GD.trail=[];
  $("gd-lrv").textContent = "η = "+gdLr().toFixed(3);
  $("gd-out").textContent = "drop the marble a few times — it lands in different valleys";
  gdDraw(); };

/* ============================================================
   5 · ATTENTION HEAD — real softmax(QKᵀ/√d)V over 4 tokens
   ============================================================ */
const AT = {
  toks: ["the","cat","sat","down"],
  // embedding dims: [nouny, function-word, verby, particle]
  E: [ [ .15, .95, .05, .10],   // the
       [ .95, .10, .25, .05],   // cat
       [ .15, .05, .95, .35],   // sat
       [ .10, .15, .30, .95] ], // down
  // Wq is a grammar-role rotation: "what am I looking for, given what I am"
  //  verbs seek nouns · nouns seek their determiner · particles seek their verb
  Wq: [[0,0,2.2,0],[1.6,0,0,0],[0,0,0,2.4],[0,1.0,0,0]],
  Wk: [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]   // keys just advertise the role
};
const matv = (M,v) => M.map(r => r.reduce((s,m,i)=>s+m*v[i],0));
const dot  = (a,b) => a.reduce((s,ai,i)=>s+ai*b[i],0);
function atWeights(T){
  const Q = AT.E.map(e=>matv(AT.Wq,e)), K = AT.E.map(e=>matv(AT.Wk,e));
  return Q.map(q => {
    const sc = K.map(k => dot(q,k)/(Math.sqrt(4)*T));
    const mx = Math.max(...sc), ex = sc.map(s=>Math.exp(s-mx)), Z = ex.reduce((a,b)=>a+b,0);
    return ex.map(e=>e/Z);
  });
}
function atDraw(){
  const T = parseFloat($("at-temp").value);
  $("at-tv").textContent = "T = "+T.toFixed(2);
  const W = atWeights(T);
  const g = $("at-grid");
  let html = `<div class="hd"></div>` + AT.toks.map(t=>`<div class="hd">${t}</div>`).join("");
  W.forEach((row,i) => {
    html += `<div class="hd">${AT.toks[i]} →</div>`;
    row.forEach(w => {
      const a = Math.min(1, .12 + w*1.1);
      html += `<div class="cellw" style="background:rgba(245,200,107,${a.toFixed(2)})">${w.toFixed(2)}</div>`;
    });
  });
  g.innerHTML = html;
  const i = W[2].indexOf(Math.max(...W[2]));
  $("at-out").textContent = `each row sums to 1.00 (it's a probability distribution) · right now "sat" puts ${(W[2][i]*100).toFixed(0)}% of its attention on "${AT.toks[i]}"`;
}
$("at-temp").addEventListener("input", atDraw);
INIT.attention = atDraw;

})(); /* end module */
